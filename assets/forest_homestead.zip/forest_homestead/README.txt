Forest Homestead, a panorama for FancyMenu: a log cabin in a forest clearing at sunset, built and captured in Minecraft.

Free to use, for testing and in your own modpacks and other projects.

To use it, put this forest_homestead folder into config/fancymenu/panoramas/ of your game directory and reload FancyMenu
(Ctrl + Alt + R, or Cmd + Alt + R on macOS) or restart the game. The Panoramas page of the FancyMenu docs shows how to use it.
